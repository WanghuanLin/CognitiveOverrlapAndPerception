function [RT,dec,t,rons_fix,rons_stim,rons_rate,rons_feedback]=present_SE_PER(fix_dur,stim_dur,blank_dur,window,slack,agrK,disK,shape_win,labels,fixs,t,texts,agree_code,img,feedback_dur,feedback_win)

%1. fixation
Screen('DrawLines',window,fixs.pos,fixs.wid,fixs.color,fixs.center,2);
rons_fix=Screen('Flip',window,t-slack);%fixation window
t=t+fix_dur; %

%2. pairs
Screen('DrawTexture',window,shape_win,[],img.pos); % shape window
Screen('DrawText',window,labels,texts.pos(1), texts.pos(2),[255,255,255]);  % labels
Screen('DrawLines',window,fixs.pos,fixs.wid,fixs.color,fixs.center,2);
rons_stim=Screen('Flip',window,t-slack);
t=t+stim_dur; %

%3. responses in the blank
rons_rate=Screen('Flip',window,t-slack);

RT=0;
dec=0;
offset=GetSecs-rons_rate;
while offset<blank_dur-0.002 
    offset=GetSecs-rons_rate;
    [keyIsDown,secs,keyCode]=KbCheck;

    if keyCode(agrK)
        RT=secs-rons_stim;
        dec=1;
        break;
    end

    if keyCode(disK)
        RT=secs-rons_stim;
        dec=0;
        break;
    end
end

t=t+blank_dur;

%4. feedback
if dec==agree_code && RT >0 % if corrected
    Screen('DrawTexture',window,feedback_win(1)); % correct feedback.
    
else % if wrong
    Screen('DrawTexture',window,feedback_win(2)); % incorrect feedback
    
end

rons_feedback=Screen('Flip',window,t-slack);
t=t+feedback_dur;

