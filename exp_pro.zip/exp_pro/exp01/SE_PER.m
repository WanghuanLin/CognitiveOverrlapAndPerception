function SE_PER(name,ID,gender)
clc;clear
path=pwd;
name=inputdlg('����������,subID','��������',[1 60],{''});
ID=inputdlg('��������','����id',[1 60],{''});
gender=inputdlg('�������Ա���1��Ů2','�����Ա�',[1 60],{''});
Screen('Close');
name=cell2mat(name);
gender=str2num(cell2mat(gender));
ID=str2num(cell2mat(ID));
Screen('Preference','SkipSyncTests',1);

%% 2. data collecting: open an .txt file here.
abc=fix(clock);
if char(gender)==1
    fidraw=fopen([path '\Data\SE_PER_main_' name '_' num2str(ID) '_' num2str(abc(4)) '_' num2str(abc(5)) '_Male.txt'],'a');
elseif char(gender)==2
    fidraw=fopen([path '\Data\SE_PER_main_' name '_' num2str(ID) '_' num2str(abc(4)) '_' num2str(abc(5)) '_Female.txt'],'a');
end

fprintf(fidraw,'Date \t Name \t ID \t Gender \t Trial \t Run_numb \t RT \t Correctness \t Shape_IDs \t Labels \t Condition_label \t Agreement \t Condition_shape \t Decision \t rons_fix \t rons_stim \t rons_dec \t rons_feedback \t gameon \t \n');

for run=1:3

%% 3. open a main window: our stimuli will be presented in this main window (for the whole of the experiment)
HideCursor;
[window,HCenter,VCenter,slack]=creat_mainWin; %employ the function of "creat_mainWin" here.

%% 4. initilizing experimental parameters
trialnum=72; % 72 trials for each run
RT=zeros(1,trialnum);
dec=zeros(1,trialnum);
rons_fix=zeros(1,trialnum);
rons_stim=zeros(1,trialnum);
rons_rate=zeros(1,trialnum);
rons_feedback=zeros(1,trialnum);
%setting up keys.
startK=KbName('s');
startK2=KbName('S');
agrK=KbName('b');
disK=KbName('n');


%setting up durations
fix_dur=0.4;
stim_dur=0.1;
blank_dur=0.8+0.4*rand(1,trialnum);
feedback_dur=0.5;

%% 5. setting up sequences.
seq=zeros(5,trialnum);
labels={'�й���','�ձ���','�޹���'};
if mod(ID,6)==1 % six possible conterbalances
    pairs(3,:)   =  [1,1,2,2,3,3,4,4,5,5,6,6]; %conditions:1=Chinese-label_match; 2=Chinese-label_unmatch; 3=Japanese-label_match; 4=Japanese-label_unmatch; 5=Stateless-label_match; 6=Stateless-label_unmatch
    pairs(2,:)   =  [1,1,1,1,2,2,2,2,3,3,3,3]; %label IDs
    pairs(4,:)   =  [1,1,0,0,1,1,0,0,1,1,0,0]; %1=agree; 2=disagree
    pairs(1,:)   =  [1,1,2,3,2,2,1,3,3,3,1,2]; %shape IDs    
    pairs(5,:)   =  [1,1,4,6,3,3,2,6,5,5,2,4]; %conditions:1=Chinese-shape_match; 2=Chinese-shape_unmatch; 3=Japanese-shape_match; 4=Japanese-shape_unmatch; 5=Stateless-shape_match; 6=Stateless-shape_unmatch
    
    inst_img=imread([path '\Pic\se_pre_inst_1.jpg'],'jpg'); %instruction images
    
elseif mod(ID,6)==2
    pairs(3,:)   =  [1,1,2,2,3,3,4,4,5,5,6,6]; %conditions:1=Chinese-label_match; 2=Chinese-label_unmatch; 3=Japanese-label_match; 4=Japanese-label_unmatch; 5=Stateless-label_match; 6=Stateless-label_unmatch
    pairs(2,:)   =  [1,1,1,1,2,2,2,2,3,3,3,3]; %label IDs
    pairs(4,:)   =  [1,1,0,0,1,1,0,0,1,1,0,0]; %1=agree; 2=disagree
    pairs(1,:)   =  [1,1,2,3,3,3,1,2,0,1,3]; %shape IDs
    pairs(5,:)   =  [1,1,6,4,3,3,2,6,5,5,2,4]; %conditions:1=Chinese-shape_match; 2=Chinese-shape_unmatch; 3=Japanese-shape_match; 4=Japanese-shape_unmatch; 5=Stateless-shape_match; 6=Stateless-shape_unmatch
    
    inst_img=imread([path '\Pic\se_pre_inst_2.jpg'],'jpg'); %instruction images
    
elseif mod(ID,6)==3
    pairs(3,:)   =  [1,1,2,2,3,3,4,4,5,5,6,6]; %conditions:1=Chinese-label_match; 2=Chinese-label_unmatch; 3=Japanese-label_match; 4=Japanese-label_unmatch; 5=Stateless-label_match; 6=Stateless-label_unmatch
    pairs(2,:)   =  [1,1,1,1,2,2,2,2,3,3,3,3]; %label IDs
    pairs(4,:)   =  [1,1,0,0,1,1,0,0,1,1,0,0]; %1=agree; 2=disagree
    pairs(1,:)   =  [2,2,1,3,1,1,2,3,3,3,1,2]; %shape IDs
    pairs(5,:)   =  [1,1,4,6,3,3,2,6,5,5,4,2];%conditions:1=Chinese-shape_match; 2=Chinese-shape_unmatch; 3=Japanese-shape_match; 4=Japanese-shape_unmatch; 5=Stateless-shape_match; 6=Stateless-shape_unmatch
    
    inst_img=imread([path '\Pic\se_pre_inst_3.jpg'],'jpg'); %instruction images
    
elseif mod(ID,6)==4
    pairs(3,:)   =  [1,1,2,2,3,3,4,4,5,5,6,6]; %conditions:1=Chinese-label_match; 2=Chinese-label_unmatch; 3=Japanese-label_match; 4=Japanese-label_unmatch; 5=Stateless-label_match; 6=Stateless-label_unmatch
    pairs(2,:)   =  [1,1,1,1,2,2,2,2,3,3,3,3]; %label IDs
    pairs(4,:)   =  [1,1,0,0,1,1,0,0,1,1,0,0]; %1=agree; 2=disagree
    pairs(1,:)   =  [2,2,1,3,3,3,1,2,1,1,2,3]; %shape IDs
    pairs(5,:)   =  [1,1,6,4,3,3,6,2,5,5,2,4]; %conditions:1=Chinese-shape_match; 2=Chinese-shape_unmatch; 3=Japanese-shape_match; 4=Japanese-shape_unmatch; 5=Stateless-shape_match; 6=Stateless-shape_unmatch

    
    inst_img=imread([path '\Pic\se_pre_inst_4.jpg'],'jpg'); %instruction images

elseif mod(ID,6)==5
    pairs(3,:)   =  [1,1,2,2,3,3,4,4,5,5,6,6]; %conditions:1=Chinese-label_match; 2=Chinese-label_unmatch; 3=Japanese-label_match; 4=Japanese-label_unmatch; 5=Stateless-label_match; 6=Stateless-label_unmatch
    pairs(2,:)   =  [1,1,1,1,2,2,2,2,3,3,3,3]; %label IDs
    pairs(4,:)   =  [1,1,0,0,1,1,0,0,1,1,0,0]; %1=agree; 2=disagree
    pairs(1,:)   =  [3,3,1,2,1,1,2,3,2,2,1,3]; %shape IDs
    pairs(5,:)   =  [1,1,4,6,3,3,6,2,5,5,4,2]; %conditions:1=Chinese-shape_match; 2=Chinese-shape_unmatch; 3=Japanese-shape_match; 4=Japanese-shape_unmatch; 5=Stateless-shape_match; 6=Stateless-shape_unmatch
    
    inst_img=imread([path '\Pic\se_pre_inst_5.jpg'],'jpg'); %instruction images

elseif mod(ID,6)==0
    pairs(3,:)   =  [1,1,2,2,3,3,4,4,5,5,6,6]; %conditions:1=Chinese-label_match; 2=Chinese-label_unmatch; 3=Japanese-label_match; 4=Japanese-label_unmatch; 5=Stateless-label_match; 6=Stateless-label_unmatch
    pairs(2,:)   =  [1,1,1,1,2,2,2,2,3,3,3,3]; %label IDs
    pairs(4,:)   =  [1,1,0,0,1,1,0,0,1,1,0,0]; %1=agree; 2=disagree
    pairs(1,:)   =  [3,3,1,2,2,2,1,3,1,1,2,3]; %shape IDs
    pairs(5,:)   =  [1,1,6,4,3,3,6,2,5,5,4,2]; %conditions:1=Chinese-shape_match; 2=Chinese-shape_unmatch; 3=Japanese-shape_match; 4=Japanese-shape_unmatch; 5=Stateless-shape_match; 6=Stateless-shape_unmatch

    
    inst_img=imread([path '\Pic\se_pre_inst_6.jpg'],'jpg'); %instruction images

end

seq(1:5,:)=repmat(pairs,1,6); %8 trials for each possible pair.
seq=seq(:,randperm(trialnum));

cue=1;
while cue
    cue=0;
    for i=trialnum-2
        if seq(5,i)==seq(5,i+1) && seq(5,i)==seq(5,i+2) %if repeated more than 3 times.
            cue=1;
            break;
        end
    end
end

%% 5. setting up dictator windows

%instructions
inst_img2=imread([path '\Pic\se_pre_inst_break.jpg'],'jpg'); %instruction images for 2nd and 3rd runs.

inst_win=Screen('MakeTexture',window,inst_img);
inst_win2=Screen('MakeTexture',window,inst_img2);

inst_img3=imread([path '\Pic\exp_pro'],'jpg'); %instruction images for 2nd and 3rd runs.
inst_win3=Screen('MakeTexture',window,inst_img3);

%shape images and windows
for i=1:3
    shape_img=imread([path '\Pic\shape_' num2str(i) '.jpg'],'jpg');
    shape_win(i)=Screen('MakeTexture',window,shape_img);
end


for i=1:2
    feedback_img=imread([path '\Pic\feedback_' num2str(i) '.jpg'],'jpg');
    feedback_win(i)=Screen('MakeTexture',window,feedback_img);
end
%% 6. positions, etc
%position of images
[hig wid x]=size(shape_img);
img.pos=[HCenter-wid/2 VCenter-hig/2-100 HCenter+wid/2 VCenter+hig/2-100];

%positions of round number and total earnings
texts.pos=[HCenter-60, VCenter+50];

%% fixation
len=30; %length of the fixatoin
fixs.pos=[-len len 0 0;0 0 -len len];
fixs.wid=4; %width of the fixation
fixs.center=[HCenter, VCenter];
fixs.color=[255 255 255];

%% 7. ready window%%%

%present instructions
if run==1
    Screen('DrawTexture',window,inst_win);
elseif run>1
    Screen('DrawTexture',window,inst_win2);
end
    
Screen('Flip',window);
while 1
    [keyIsDown,secs,keyCode]=KbCheck;
    if keyCode(startK)||keyCode(startK2)
        break;
    end
end
t=GetSecs+2;

Screen('DrawTexture',window,inst_win3);
Screen('Flip',window);
while 1
    [keyIsDown,secs,keyCode]=KbCheck;
    if keyCode(startK)||keyCode(startK2)
        break;
    end
end
t=GetSecs+2; %This is when experiment begins
gameon=t;

%% 8. loop for each trial. Need "present_PDG" here.
for i=1:trialnum
    [RT(i),dec(i),t,rons_fix(i),rons_stim(i),rons_rate(i),rons_feedback(i)]=present_SE_PER(fix_dur,stim_dur,blank_dur(i),window,slack,agrK,disK,shape_win(seq(1,i)),double(labels{seq(2,i)}),fixs,t,texts,seq(4,i),img,feedback_dur,feedback_win(:)); % 
end

%% 9. collecting data for each run

for i=1:trialnum
    fprintf(fidraw,'%s\t',date);
    fprintf(fidraw,'%s\t',name);
    fprintf(fidraw,'%3d\t',ID);
    fprintf(fidraw,'%3d\t',gender);
    fprintf(fidraw,'%3d\t',i);  % trial number
    fprintf(fidraw,'%2d\t',run); % run number
    fprintf(fidraw,'%6.3f\t',RT(i));  %RT
    fprintf(fidraw,'%2d\t',dec(i)==seq(4,i) & RT(i)>0); %1=correct; 0=incorrect
    fprintf(fidraw,'%2d\t',seq(1,i)); %shape IDs
    fprintf(fidraw,'%2d\t',seq(2,i)); %labels
    fprintf(fidraw,'%2d\t',seq(3,i)); %condition_label
    fprintf(fidraw,'%2d\t',seq(4,i)); %agreement
    fprintf(fidraw,'%2d\t',seq(5,i)); %condition_shape
    fprintf(fidraw,'%2d\t',dec(i)); %
    fprintf(fidraw,'%6.3f\t',rons_fix(i));  %onsets of fix
    fprintf(fidraw,'%6.3f\t',rons_stim(i));  %onsets of stim
    fprintf(fidraw,'%6.3f\t',rons_rate(i));  %onsets of decision
    fprintf(fidraw,'%6.3f\t',rons_feedback(i));  %onsets of feedback
    fprintf(fidraw,'%6.3f\t',gameon);  %onsets of game
    fprintf(fidraw,'\n');
end


%final fixation.
Screen('DrawLines',window,fixs.pos,fixs.wid,fixs.color,fixs.center,2);
t=GetSecs+0.5;
Screen('Flip',window,t-slack);%fixation window
t=GetSecs+3;
Screen('Flip',window,t-slack);%fixation window

Screen ('CloseAll');  %must use this one to get rid of syn problems.
clear seq labels shape_win agrK disK feedback_win window fixs t slack RT dec trialnum fix_dur context_dur outcome_dur final_id accK rejK outcome_pos dec_pos outcome_win dec_win dictator_win texts outcome player_a pa_pos
end
%% clear all stuff after each run
Screen ('CloseAll');  %must use this one to get rid of syn problems.
status=fclose(fidraw);
clear all;